@echo off
setlocal
cd /d "%~dp0"
if not exist "lib\mysql-connector-j.jar" (
  echo Missing MySQL Connector/J: lib\mysql-connector-j.jar
  echo Download MySQL Connector/J from https://dev.mysql.com/downloads/connector/j/
  echo Place the JAR in the lib folder and run this script again.
  pause
  exit /b 1
)
if not exist "dist\CherryCosmetics.jar" (
  echo Built application JAR was not found. Open this project in NetBeans and choose Clean and Build Project.
  pause
  exit /b 1
)
java -cp "dist\CherryCosmetics.jar;lib\mysql-connector-j.jar" cherrycosmetics.Main
if errorlevel 1 pause
endlocal
